"LUT Table Pack" (PNG) by Tom Shannon. No license specified. 
https://forums.unrealengine.com/community/community-content-tools-and-tutorials/19151-lut-table-pack?48641-LUT-Table-Pack=

"Free LUTs Cinematic" (Cube & 3DL) by Presetpro. No license specified. 
https://www.freepresets.com/product/free-luts-cinematic/

"35 Free LUTs for Color Grading Videos" (Cube) by Rocketstock. No license specified. 
https://www.rocketstock.com/free-after-effects-templates/35-free-luts-for-color-grading-videos/
