https://github.com/google/material-design-icons
google/material-design-icons is licensed under the Apache License 2.0.
